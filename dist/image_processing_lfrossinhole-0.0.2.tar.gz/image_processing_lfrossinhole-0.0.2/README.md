# image_processing

Description.
The package image_processing_lfrossinhole is used to: <br>
-	Processing: <br>
		- Histogram matching  <br>
		- Structural similarity <br>
		- Resize image
-	Utils: <br>
		- Read image <br>
		- Save image <br>
		- Plot image <br>
		- Plot result <br>
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_lfrossinhole

```bash
pip install image_processing_lfrossinhole
```

## Author
Lucas Feitosa

## License
[MIT](https://choosealicense.com/licenses/mit/)